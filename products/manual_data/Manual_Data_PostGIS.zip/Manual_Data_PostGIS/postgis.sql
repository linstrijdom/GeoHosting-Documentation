-- ============================================================
-- 0. Enable PostGIS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS postgis;

-- ============================================================
-- 1. DROP EXISTING TABLES (optional cleanup)
-- ============================================================
DROP TABLE IF EXISTS places CASCADE;
DROP TABLE IF EXISTS place_types CASCADE;
DROP TABLE IF EXISTS admin_boundaries CASCADE;

-- ============================================================
-- 2. CREATE LOOKUP TABLE: place_types
-- ============================================================
CREATE TABLE place_types (
    id INTEGER PRIMARY KEY,
    label CHARACTER(128) NOT NULL
);

INSERT INTO place_types (id, label) VALUES
(1, 'City'),
(2, 'Town'),
(3, 'Village'),
(4, 'Settlement');

-- ============================================================
-- 3. CREATE places TABLE
-- ============================================================
CREATE TABLE places (
    id          INTEGER PRIMARY KEY,
    name        CHARACTER(256) NOT NULL,
    population  INTEGER NOT NULL,
    area_km2    NUMERIC(10,2) NOT NULL,
    place_type_id INTEGER,
    geom        geometry(Point, 4326) NOT NULL
);

-- Foreign key to lookup table
ALTER TABLE places
ADD CONSTRAINT fk_place_type
FOREIGN KEY (place_type_id)
REFERENCES place_types(id);

-- ============================================================
-- 4. INSERT SAMPLE PLACES (10 POINTS IN WESTERN CAPE)
-- Coordinates = lon, lat (EPSG:4326)
-- ============================================================
INSERT INTO places (id, name, population, area_km2, place_type_id, geom)
VALUES
(1, 'Cape Town',        4600000, 2450, 1, ST_SetSRID(ST_Point(18.4233, -33.9189), 4326)),
(2, 'Paarl',             285000,  400,  2, ST_SetSRID(ST_Point(18.9637, -33.7342), 4326)),
(3, 'Stellenbosch',      200000,  150,  2, ST_SetSRID(ST_Point(18.8650, -33.9344), 4326)),
(4, 'Worcester',         120000,  140,  2, ST_SetSRID(ST_Point(19.4450, -33.6460), 4326)),
(5, 'Franschhoek',         7000,   20,  3, ST_SetSRID(ST_Point(19.1222, -33.9100), 4326)),
(6, 'Malmesbury',         36000,  100,  2, ST_SetSRID(ST_Point(18.7290, -33.4620), 4326)),
(7, 'Wellington',         62000,   90,  2, ST_SetSRID(ST_Point(19.0170, -33.6330), 4326)),
(8, 'Grabouw',            45000,   70,  2, ST_SetSRID(ST_Point(19.0120, -34.1510), 4326)),
(9, 'Hermanus',           49000,   65,  2, ST_SetSRID(ST_Point(19.2340, -34.4090), 4326)),
(10,'Ceres',              44000,   85,  2, ST_SetSRID(ST_Point(19.3070, -33.3680), 4326));

-- ============================================================
-- 5. CREATE SMALL admin_boundaries POLYGON LAYER
-- ============================================================
CREATE TABLE admin_boundaries (
    id INTEGER PRIMARY KEY,
    name CHARACTER(256) NOT NULL,
    geom geometry(Polygon, 4326) NOT NULL
);

-- City of Cape Town boundary (simplified box)
INSERT INTO admin_boundaries (id, name, geom)
VALUES (
    1, 'Cape Town',
    ST_SetSRID(
        ST_PolygonFromText(
            'POLYGON((
                18.25 -34.20,
                18.25 -33.70,
                18.70 -33.70,
                18.70 -34.20,
                18.25 -34.20
            ))'
        ), 4326
    )
);

-- Drakenstein Municipality (Paarl/Wellington area)
INSERT INTO admin_boundaries (id, name, geom)
VALUES (
    2, 'Drakenstein',
    ST_SetSRID(
        ST_PolygonFromText(
            'POLYGON((
                18.80 -33.90,
                18.80 -33.55,
                19.20 -33.55,
                19.20 -33.90,
                18.80 -33.90
            ))'
        ), 4326
    )
);

-- Stellenbosch Municipality
INSERT INTO admin_boundaries (id, name, geom)
VALUES (
    3, 'Stellenbosch',
    ST_SetSRID(
        ST_PolygonFromText(
            'POLYGON((
                18.70 -34.05,
                18.70 -33.80,
                19.10 -33.80,
                19.10 -34.05,
                18.70 -34.05
            ))'
        ), 4326
    )
);

-- ============================================================
-- DONE 🎉
-- ============================================================